import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Test_Suite {

    public static void main(String[] args) throws IOException, InterruptedException {
        WebDriver driver = null;
        {
            File file;
            if (System.getProperty("os.name").contains("Mac")) {
                file = new File("src/main/resources/chromedriver").getCanonicalFile();
            } else {
                file = new File("src/main/resources/chromedriver.exe").getCanonicalFile();
            }

            System.setProperty("webdriver.chrome.driver", file.getAbsolutePath().replace("\\", "\\\\"));
            try {
                ChromeOptions options = new ChromeOptions();
                //	options.addArguments("--disable-extensions");

                driver = new ChromeDriver(options);
                driver.manage().window().maximize();

            } catch (Exception e) {
                e.printStackTrace();
            }

            driver.get("https://app.vwo.com/#/analyze/heatmap/129/reports?token=eyJhY2NvdW50X2lkIjo2LCJleHBlcmltZW50X2lkIjoxMjksImNyZWF0ZWRfb24iOjE1MDc3ODk0ODcsInR5cGUiOiJjYW1wYWlnbiIsInZlcnNpb24iOjEsImhhc2giOiJiMzlmMTQ4MWE0ZDMyN2Q4MDllNTM1YzVlNWFjOGVlMCJ9");
            Thread.sleep(10000);
            WebDriverWait wait = new WebDriverWait(driver,160);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@data-qa='voferojeve']/..")));
            Actions act= new Actions(driver);
            act.moveToElement(driver.findElement(By.xpath("//*[@data-qa='voferojeve']/..")));
            driver.findElement(By.xpath("//div[contains(text(), \"View heatmap\")]")).click();
          //driver.switchTo(By.xpath("//a[@href=\"https://vwo.com/pricing/\"]"));
            ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
            driver.switchTo().window(tabs2.get(2));
            Thread.sleep(10000);
            System.out.println(driver.getCurrentUrl());
            driver.switchTo().frame("heatmap-iframe");
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(), \"Element List\")]")));
            driver.findElement(By.xpath("//span[contains(text(), \"Element List\")]")).click();
            Thread.sleep(5000);
            driver.switchTo().defaultContent();
            driver.switchTo().frame("element-list-iframe");
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"element-list--content\"]/tr[2]/td[1]")));
            driver.findElement(By.xpath("//*[@id=\"element-list--content\"]/tr[2]/td[1]")).click();
            driver.close();
        }
    }
}
